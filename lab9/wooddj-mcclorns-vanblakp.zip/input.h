#include <string>
using namespace std;

int toInt(char);
int toInt(char);
int askInt();
int askInt(string);
string removeSpaces(string);
bool isInt(string);

