#include <string>
#pragma once
using namespace std;

class FullShelf {
public:
    string errorMessage;
};
