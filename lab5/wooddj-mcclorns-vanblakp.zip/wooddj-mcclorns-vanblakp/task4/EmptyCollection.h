#include <string>
#pragma once
using namespace std;

class EmptyCollection {
public:
    string errorMessage;
};
