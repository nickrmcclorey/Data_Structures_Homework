#include <string>
#pragma once
using namespace std;

class FullCollection {
public:
    string errorMessage;
};
