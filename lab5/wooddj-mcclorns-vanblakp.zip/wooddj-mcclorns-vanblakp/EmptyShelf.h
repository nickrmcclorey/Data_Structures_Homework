#include <string>
#pragma once
using namespace std;

class EmptyShelf {
public:
    string errorMessage;
};
