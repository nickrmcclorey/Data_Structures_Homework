
struct Move {
    int from;
    int to;
    Move(int fromIn, int toIn) {
        from = fromIn;
        to = toIn;
    }
};